<!doctype html>
<html lang="en-us">
   <head>
      <meta charset="UTF-8">
      <title>Кинотеатр</title>
   </head>
   <body>
      <h3>Список фильмов</h3>
      <form method="POST" action="SummProct.php">
         <table>
            <tr>
               <td>
                  <select name="name">
                  <?php
                     $mysqli=new mysqli('localhost','root','','mybase');
                     if ($mysqli->connect_errno) {
                     	echo "Не удалось подключиться к MySQL: " . mysqli_connect_error();
                     	return false;
                     };
                     $mysqli->set_charset("utf8");
                     $text="select distinct name from films"; 
                     $result=$mysqli->query($text);
                     while ($row = mysqli_fetch_assoc($result)){
                     	echo "<option>".$row['name']."</option>";
                     }
                     ?>
                  </select>
               </td>
               <td>
                  <select name="sign">
                     <option>></option>
                     <option>=</option>
                     <option><</option>
                  </select>
               </td>
               <td><input name="price"></td>
            <tr>
         </table>
         <input type="submit">
      </form>
   </body>
</html>